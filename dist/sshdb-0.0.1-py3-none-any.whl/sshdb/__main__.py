from . import manager

manager.main()
